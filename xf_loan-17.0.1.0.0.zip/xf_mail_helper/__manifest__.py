# -*- coding: utf-8 -*-
{
    'name': 'XF Discussing Mixins',
    'version': '1.0.0',
    'category': 'hidden',
    'summary': """
    This extension allows to append to mail.message body additional text using the context mail_reason_body
    """,
    'author': 'XFanis',
    'support': 'xfanis.dev@gmail.com',
    'website': 'https://xfanis.dev/odoo.html',
    'description':
        """
        This extension allows to append to mail.message body additional text using the context mail_reason_body
        """,
    'depends': ['mail'],
    'installable': True,
    'auto_install': False,
    'application': False,
    'license': 'LGPL-3',
}
